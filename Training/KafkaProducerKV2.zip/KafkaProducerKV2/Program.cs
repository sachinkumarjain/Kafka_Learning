﻿using Confluent.Kafka;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace KafkaProducerKV2
{
    class Program
    {
        public static async Task Main(string[] args)
        {
            string topic = args[0];

            var conf = new ProducerConfig {
                BootstrapServers = "localhost:9092",
                Acks = Acks.None, 
                RetryBackoffMs = 1000,
                BatchNumMessages = 100,
                QueueBufferingMaxKbytes = 1048576,
                QueueBufferingMaxMessages = 100
            };
            

            Action<DeliveryReport<string, string>> handler = deliveryReport =>
            {
                if (!deliveryReport.Error.IsError)
                {
                    Console.WriteLine($"Delivered message to {deliveryReport.TopicPartitionOffset}, " +
                        $"Key: {deliveryReport.Key}, " +
                        $"Value: {deliveryReport.Value}");
                }
                else
                {
                    Console.WriteLine($"Delivery Error: {deliveryReport.Error.Reason}");
                }
            };

            using (var p = new ProducerBuilder<string, string>(conf).Build())
            {
                Console.WriteLine("\n-----------------------------------------------------------------------");
                Console.WriteLine($"Producer 'KafkaProducerKV2' producing on topic '{topic}'.");
                Console.WriteLine("-----------------------------------------------------------------------");
                Console.WriteLine("To create a kafka message with UTF-8 encoded key and value:");
                Console.WriteLine("> key value<Enter>");
                Console.WriteLine("To create a kafka message with a null key and UTF-8 encoded value:");
                Console.WriteLine("> value<enter>");
                Console.WriteLine("Ctrl-C to quit.\n");

                var cancelled = false;

                Console.CancelKeyPress += (_, e) => {
                    e.Cancel = true; // prevent the process from terminating.
                    cancelled = true;
                };

                while (!cancelled)
                {
                    Console.Write("> ");

                    string text;

                    try
                    {
                        text = Console.ReadLine();
                    }
                    catch (IOException)
                    {
                        break;
                    }

                    if (text == null)
                    {
                        break;
                    }

                    string key = null;
                    string val = text;

                    // split line if both key and value specified.
                    int index = text.IndexOf(" ");

                    if (index != -1)
                    {
                        key = text.Substring(0, index);
                        val = text.Substring(index + 1);
                    }

                    try
                    {
                        var r = await p.ProduceAsync(
                            topic, new Message<string, string> { Key = key, Value = val });

                        Console.WriteLine($"delivered to: {r.TopicPartitionOffset}, key: {r.Key}, value: {r.Value}");
                    }
                    catch (ProduceException<string, string> e)
                    {
                        Console.WriteLine($"failed to deliver message: {e.Message} [{e.Error.Code}]");
                    }
                }
            }
        }
    }
}
