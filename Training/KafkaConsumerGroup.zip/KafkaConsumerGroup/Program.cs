﻿using System;

namespace KafkaConsumerGroup
{
    using System;
    using System.Threading;
    using Confluent.Kafka;

    class Program
    {
        public static void Main(string[] args)
        {
            string topic = args[0];

            var conf = new ConsumerConfig
            {
                GroupId = "group-1",
                BootstrapServers = "localhost:9092",
                AutoOffsetReset = AutoOffsetReset.Latest
            };

            using (var c = new ConsumerBuilder<Ignore, string>(conf).Build())
            {
                c.Subscribe(topic);

                CancellationTokenSource cts = new CancellationTokenSource();
                Console.CancelKeyPress += (_, e) => {
                    e.Cancel = true; // prevent the process from terminating.
                    cts.Cancel();
                };

                try
                {
                    while (true)
                    {
                        try
                        {
                            var cr = c.Consume(cts.Token);

                            Console.WriteLine($"Message '{cr.Value}', " +
                                $"Topic '{cr.Topic}', " +
                                $"Partition '{cr.Partition}', " +
                                $"Offset: '{cr.TopicPartitionOffset}'");
                        }
                        catch (ConsumeException e)
                        {
                            Console.WriteLine($"Error occured: {e.Error.Reason}");
                        }
                    }
                }
                catch (OperationCanceledException)
                {
                    // Ensure the consumer leaves the group cleanly and final offsets are committed.
                    c.Close();
                }
            }
        }
    }
}
