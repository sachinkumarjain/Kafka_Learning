﻿using System;

namespace KafkaProducerKV
{
    using System;
    using Confluent.Kafka;

    class Program
    {
        public static void Main(string[] args)
        {
            var conf = new ProducerConfig { BootstrapServers = "localhost:9092" };
            string topic = args[0];

            Action<DeliveryReport<int, string>> handler = deliveryReport =>
                {
                    if (!deliveryReport.Error.IsError)
                    {
                        Console.WriteLine($"Delivered message to {deliveryReport.TopicPartitionOffset}, " +
                            $"Key: {deliveryReport.Key}, " +
                            $"Value: {deliveryReport.Value}");
                    }
                    else
                    {
                        Console.WriteLine($"Delivery Error: {deliveryReport.Error.Reason}");
                    }
                };                

            using (var p = new ProducerBuilder<int, string>(conf).Build())
            {
                for (int i = 0; i < 10; ++i)
                {
                    int key = i % 3;
                    string value = "Message " + i;

                    p.Produce(topic, new Message<int, string> { Key = key, Value = value }, handler);
                }

                // wait for up to 10 seconds for any inflight messages to be delivered.
                p.Flush(TimeSpan.FromSeconds(10));
            }
        }
    }
}
