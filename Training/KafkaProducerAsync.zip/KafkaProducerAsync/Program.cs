﻿
namespace KafkaProducerAsync
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using Confluent.Kafka;
    using System.Threading.Tasks;

    class Program
    {

        public static async Task Main(string[] args)
        {
            var config = new ProducerConfig { BootstrapServers = "localhost:9092" };
            var topicName = "test-topic";

            using (var p = new ProducerBuilder<string, string>(config).Build())
            {
                try
                {
                    // Note: Awaiting the asynchronous produce request below prevents flow of execution
                    // from proceeding until the acknowledgement from the broker is received.

                    for (int i = 0; i < 10; ++i)
                    {
                        var key = i.ToString();
                        var value = "Message " + i;

                        var deliveryReport = await p.ProduceAsync(
                                    topicName, 
                                    new Message<string, string> { Key = key, Value = value }
                                );

                        Console.WriteLine($"delivered to: {deliveryReport.TopicPartitionOffset} " +
                            $"\n Key: {deliveryReport.Key}, " +
                            $" Message: {deliveryReport.Value} \n");
                    }
                }
                catch (ProduceException<string, string> e)
                {
                    Console.WriteLine($"failed to deliver message: {e.Message} [{e.Error.Code}]");
                }
            }
        }
    }
}
