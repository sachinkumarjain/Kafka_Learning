﻿namespace KafkaProducerAsyncNoWait
{
    using System;
    using Confluent.Kafka;
    //using System.Threading.Tasks;
    //using System.Collections.Generic;
    //using System.IO;
    //using System.Text;

    class Program
    {

        public static void Main(string[] args)
        {
            var config = new ProducerConfig { BootstrapServers = "localhost:9092" };
            var topicName = "test-topic";

            using (var p = new ProducerBuilder<string, string>(config).Build())
            {
                try
                {
                    for (int i = 0; i < 10; ++i)
                    {
                        var key = i.ToString();
                        var value = "(KafkaProducerAsyncNoWait) Message " + i;

                        p.ProduceAsync(topicName, new Message<string, string> { Key = key, Value = value });                        
                    }
                    p.Flush(TimeSpan.FromSeconds(10));
                    
                }
                catch (ProduceException<string, string> e)
                {
                    Console.WriteLine($"failed to deliver message: {e.Message} [{e.Error.Code}]");
                }
            }
        }
    }
}
