﻿namespace KafkaProducerMultiple
{
    using System;
    using Confluent.Kafka;

    class Program
    {
        public static void Main(string[] args)
        {
            var config = new ProducerConfig { BootstrapServers = args[0] };

            using (var producer = new ProducerBuilder<string, string>(config).Build())
            using (var producer2 = new DependentProducerBuilder<Null, string>(producer.Handle).Build())
            {
                producer.ProduceAsync("topic-1", new Message<string, string> {
                    Key = "key-from-topic-1", Value = "value-from-producer1" });

                producer2.ProduceAsync("topic-2", new Message<Null, string> { Value = "value-from-producer2" });

                producer2.ProduceAsync("topic-1", new Message<Null, string> { Value = "value-from-producer2" });

                // As the Tasks returned by ProduceAsync are not waited on there will still be messages in flight.
                producer.Flush(TimeSpan.FromSeconds(10));
            }
        }
    }
}
